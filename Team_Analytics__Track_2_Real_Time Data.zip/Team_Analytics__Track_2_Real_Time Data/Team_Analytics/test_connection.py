from db_utils import get_pg_data

df = get_pg_data(
    db="insurance_source",
    query="SELECT * FROM insurance_raw",
    limit=5
)

print(df)
