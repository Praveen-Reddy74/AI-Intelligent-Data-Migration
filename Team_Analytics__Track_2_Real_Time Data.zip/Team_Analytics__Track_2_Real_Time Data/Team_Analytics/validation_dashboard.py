# ------------------------------------
# STREAMLIT VALIDATION DASHBOARD
# ------------------------------------

import streamlit as st
from db_utils import get_pg_data


st.set_page_config(page_title="Data Migration Validation", layout="wide")

st.title("📊 Insurance Migration – Validation Report")


# -----------------------------
# ROW COUNT METRICS
# -----------------------------
source_count = get_pg_data(
    "insurance_source",
    "SELECT COUNT(*) AS cnt FROM insurance_raw"
).iloc[0, 0]

target_count = get_pg_data(
    "insurance_target",
    "SELECT COUNT(*) AS cnt FROM policy_holders"
).iloc[0, 0]


# -----------------------------
# DATA QUALITY CHECKS
# -----------------------------
null_premium = get_pg_data(
    "insurance_target",
    "SELECT COUNT(*) AS cnt FROM policy_holders WHERE premium IS NULL"
).iloc[0, 0]

date_issues = get_pg_data(
    "insurance_target",
    """
    SELECT COUNT(*) AS cnt 
    FROM policy_holders 
    WHERE start_date > end_date
    """
).iloc[0, 0]


# -----------------------------
# DISPLAY METRICS
# -----------------------------
col1, col2, col3, col4 = st.columns(4)

col1.metric("Source Rows", source_count)
col2.metric("Target Rows", target_count)
col3.metric("NULL Premiums", null_premium)
col4.metric("Date Integrity Issues", date_issues)


# -----------------------------
# STATUS SUMMARY
# -----------------------------
st.markdown("### ✅ Validation Summary")

if null_premium == 0 and date_issues == 0:
    st.success("All critical validation checks passed successfully.")
else:
    st.warning("Some validation checks need attention.")
