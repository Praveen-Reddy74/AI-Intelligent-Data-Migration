from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import difflib

SYNONYMS = {
    "id": ["id"],
    "name": ["name"],
    "email": ["email", "mail"],
    "date": ["date", "dt", "created", "signup"]
}

def normalize(col):
    return col.replace("_", " ").lower()

def heuristic_boost(src, tgt):
    score = 0
    for key, words in SYNONYMS.items():
        if any(w in src for w in words) and any(w in tgt for w in words):
            score += 0.3
    return score

def similarity(a, b):
    tfidf = TfidfVectorizer().fit_transform([a, b])
    return cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0]

source_cols = ["cust_id", "full_name", "email_address", "created_dt"]
target_cols = ["customer_id", "first_name", "last_name", "user_email", "signup_date"]

mappings = []

for s in source_cols:
    best_match = None
    best_score = 0

    for t in target_cols:
        tfidf_score = similarity(normalize(s), normalize(t))
        seq_score = difflib.SequenceMatcher(None, s, t).ratio()
        boost = heuristic_boost(normalize(s), normalize(t))

        final_score = (tfidf_score + seq_score) / 2 + boost

        if final_score > best_score:
            best_score = final_score
            best_match = t

    mappings.append({
        "source": s,
        "target": best_match,
        "confidence": round(float(best_score), 2)
    })

print(mappings)
