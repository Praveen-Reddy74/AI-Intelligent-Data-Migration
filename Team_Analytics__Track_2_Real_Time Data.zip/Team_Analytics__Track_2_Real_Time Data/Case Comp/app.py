import streamlit as st
import sqlite3
import pandas as pd
import plotly.graph_objects as go
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import difflib



#Dashboard Title + Layout
#---------------------------
st.set_page_config(page_title="AI Data Migration Intelligence", layout="wide")

st.title(" AI-Powered Intelligent Data Migration System")
st.markdown("""
This system **understands, explains, validates, and visualizes** data migration  
between heterogeneous databases.
""")


#Load Source & Target Data
#--------------------------

def load_data(db, table):
    conn = sqlite3.connect(db)
    df = pd.read_sql(f"SELECT * FROM {table}", conn)
    conn.close()
    return df

source_df = load_data("source.db", "customers")
target_df = load_data("target.db", "users")


#Show Schemas
#--------------

st.subheader(" Source Schema")
st.dataframe(source_df.head())

st.subheader(" Target Schema")
st.dataframe(target_df.head())


##AI Column Mapping Logic (Inline)
#------------------------------------

def similarity(a, b):
    tfidf = TfidfVectorizer().fit_transform([a, b])
    return cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0]

source_cols = list(source_df.columns)
target_cols = list(target_df.columns)

mapping_results = []

for s in source_cols:
    best_match = None
    best_score = 0

    for t in target_cols:
        sem = similarity(s.replace("_", " "), t.replace("_", " "))
        seq = difflib.SequenceMatcher(None, s, t).ratio()
        score = round((sem + seq) / 2, 2)

        if score > best_score:
            best_score = score
            best_match = t

    explanation = (
        f"'{s}' mapped to '{best_match}' due to semantic and lexical similarity."
        if best_score > 0.6
        else f"'{s}' has low confidence match and requires review."
    )

    mapping_results.append({
        "Source Column": s,
        "Target Column": best_match,
        "Confidence": best_score,
        "Explanation": explanation
    })

mapping_df = pd.DataFrame(mapping_results)


#Show Mapping Report
#----------------------


st.subheader(" Intelligent Column Mapping Report")
st.dataframe(mapping_df)


#Sankey Visualization
#---------------------

st.subheader(" Schema Mapping Visualization (Sankey Diagram)")

labels = []
source_indices = []
target_indices = []
values = []

for _, row in mapping_df.iterrows():
    src = row["Source Column"]
    tgt = row["Target Column"]

    if src not in labels:
        labels.append(src)
    if tgt not in labels:
        labels.append(tgt)

    source_indices.append(labels.index(src))
    target_indices.append(labels.index(tgt))
    values.append(max(row["Confidence"], 0.1))

fig = go.Figure(go.Sankey(
    node=dict(
        pad=15,
        thickness=20,
        line=dict(color="black", width=0.5),
        label=labels
    ),
    link=dict(
        source=source_indices,
        target=target_indices,
        value=values
    )
))

st.plotly_chart(fig, use_container_width=True)



#Validation Section
#-------------------

st.subheader(" Migration Validation Report")

st.metric("Source Rows", len(source_df))
st.metric("Target Rows", len(target_df))

nulls = target_df.isnull().sum()

st.write("Null Value Check")
st.dataframe(nulls)


#Explainability
#---------------

st.subheader(" Explainability")

for _, row in mapping_df.iterrows():
    st.write(f"• {row['Explanation']} (Confidence: {row['Confidence']})")



