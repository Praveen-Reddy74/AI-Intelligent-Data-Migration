import sqlite3
import pandas as pd

# Connect to databases
src = sqlite3.connect("source.db")
tgt = sqlite3.connect("target.db")

# Row count validation
src_count = pd.read_sql(
    "SELECT COUNT(*) AS cnt FROM customers",
    src
)["cnt"][0]

tgt_count = pd.read_sql(
    "SELECT COUNT(*) AS cnt FROM users",
    tgt
)["cnt"][0]

print("Row Count Validation")
print("Source:", src_count)
print("Target:", tgt_count)

# Null check on critical column
print("\nNull Check (user_email):")
null_df = pd.read_sql(
    "SELECT * FROM users WHERE user_email IS NULL",
    tgt
)

print(null_df)

# Close connections
src.close()
tgt.close()
