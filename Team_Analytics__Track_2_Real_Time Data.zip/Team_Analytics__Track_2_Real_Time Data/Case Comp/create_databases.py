import sqlite3

# SOURCE DB
src_conn = sqlite3.connect("source.db")
src_cur = src_conn.cursor()

src_cur.execute("""
CREATE TABLE customers (
    cust_id INTEGER,
    full_name TEXT,
    email_address TEXT,
    created_dt TEXT
)
""")

src_cur.executemany("""
INSERT INTO customers VALUES (?, ?, ?, ?)
""", [
    (1, "Rahul Sharma", "rahul@gmail.com", "2022-01-10"),
    (2, "Anita Verma", "anita@yahoo.com", "2022-03-15"),
    (3, "Aman Gupta", "aman@outlook.com", "2022-05-20")
])

src_conn.commit()
src_conn.close()

# TARGET DB
tgt_conn = sqlite3.connect("target.db")
tgt_cur = tgt_conn.cursor()

tgt_cur.execute("""
CREATE TABLE users (
    customer_id INTEGER,
    first_name TEXT,
    last_name TEXT,
    user_email TEXT,
    signup_date TEXT
)
""")

tgt_conn.commit()
tgt_conn.close()

print("Databases created successfully.")
