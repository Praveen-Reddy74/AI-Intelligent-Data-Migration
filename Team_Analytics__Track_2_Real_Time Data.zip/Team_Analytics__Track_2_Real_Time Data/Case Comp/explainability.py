def explain(mapping):
    explanations = []
    for m in mapping:
        if m["confidence"] > 0.7:
            reason = f"{m['source']} mapped to {m['target']} due to high semantic similarity."
        else:
            reason = f"{m['source']} has weak similarity with {m['target']} and may need manual review."

        explanations.append({
            **m,
            "explanation": reason
        })
    return explanations

from column_mapping import mappings

report = explain(mappings)

for r in report:
    print(r)
