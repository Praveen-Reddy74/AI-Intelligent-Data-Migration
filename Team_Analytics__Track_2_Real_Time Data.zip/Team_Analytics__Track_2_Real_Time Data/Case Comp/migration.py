import pandas as pd
import sqlite3

# Connect to databases
src_conn = sqlite3.connect("source.db")
tgt_conn = sqlite3.connect("target.db")

# Read source data
src_df = pd.read_sql("SELECT * FROM customers", src_conn)

# Split full_name into first and last name
src_df["first_name"] = src_df["full_name"].apply(lambda x: x.split()[0])
src_df["last_name"] = src_df["full_name"].apply(lambda x: x.split()[1])

# Prepare final dataframe for target table
final_df = pd.DataFrame({
    "customer_id": src_df["cust_id"],
    "first_name": src_df["first_name"],
    "last_name": src_df["last_name"],
    "user_email": src_df["email_address"],
    "signup_date": src_df["created_dt"]
})

# Insert into target table
final_df.to_sql("users", tgt_conn, if_exists="append", index=False)

print("Migration completed.")

# Close connections
src_conn.close()
tgt_conn.close()
