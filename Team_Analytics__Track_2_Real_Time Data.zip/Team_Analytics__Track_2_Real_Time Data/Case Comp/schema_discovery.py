import sqlite3
import pandas as pd

def get_schema(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()

    schema = {}

    for table in tables:
        table = table[0]

        cursor.execute(f"PRAGMA table_info({table})")
        cols = cursor.fetchall()

        df = pd.read_sql_query(
            f"SELECT * FROM {table} LIMIT 3",
            conn
        )

        schema[table] = {
            "columns": {col[1]: col[2] for col in cols},
            "sample_data": df
        }

    conn.close()
    return schema


source_schema = get_schema("source.db")
target_schema = get_schema("target.db")

print("SOURCE SCHEMA:")
print(source_schema)

print("\nTARGET SCHEMA:")
print(target_schema)
